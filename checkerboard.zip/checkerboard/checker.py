from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def check1():
    # return 'Sup'
    return render_template ("checkerboard.html", cross = 8, down = 8)

@app.route('/<int:num>')
def check2(num):
    return render_template('checkerboard.html', cross = 8, down = int(num))

@app.route('/<int:num1>/<int:num2>')
def check3(num1, num2):
    return render_template('checkerboard.html', cross = int(num1), down = int(num2))

# @app.route('/<int:num1>/<int:num2>/<col1>/<col2')
# def check3(num1, num2, col1, col2):
#     return render_template('checkerboard.html', cross = int(num1), down = int(num2), col1 = (col1), col2 = (col2))

if __name__=="__main__":
    app.run(debug=True)
